# def main():
#     print("This module's name is {}".format(__name__))

if __name__=='__main__':
    print("Run directly")
else:
    print("Run from import")